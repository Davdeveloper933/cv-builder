<template>
  <NuxtLayout><NuxtPage /></NuxtLayout>
</template>
<script setup lang="ts"></script>
