<script setup lang="ts"></script>

<template>
  <div>history of changes</div>
</template>

<style scoped></style>
