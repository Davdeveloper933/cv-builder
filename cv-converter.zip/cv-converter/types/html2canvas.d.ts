export {}

declare global {
  interface Window {
    html2canvas: any
  }
}
