export {}

declare global {
  interface Window {
    pdfjsLib: any
  }
}
