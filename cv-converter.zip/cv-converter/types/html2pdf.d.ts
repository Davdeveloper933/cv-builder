export {}

declare global {
  interface Window {
    html2pdf: any
  }
}
